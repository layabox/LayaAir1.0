 README
## This is the README for your extension "word-count"

THe Word-Count extension can count how many words in that opened markdown file.
*It now only support the markdown file.*
*It will auto_start when you open makedown file.*
This project was made by the following guides:
[Example - Word Count](https://code.visualstudio.com/docs/extensions/example-word-count)

**Enjoy! (づ￣ 3￣)づ**
