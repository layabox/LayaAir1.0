The JavaScript.tmLanguage bundle is derived from the TypeScriptReact.tmLanguage.

Changes:
- fileTypes .tsx -> .js
- scopeName scopr.tsx -> scope.js
- update language name and file types
