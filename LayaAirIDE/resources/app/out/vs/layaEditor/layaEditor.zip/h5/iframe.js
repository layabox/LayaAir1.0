function test(msg){
	document.body.innerHTML = msg
}