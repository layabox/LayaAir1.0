// The module 'vscode' contains the VS Code extensibility API
// Import the module and reference it with the alias vscode in your code below
let vscode = require('vscode');
let fs = require('fs');
let path = require('path');

let Range = vscode.Range;
let Position = vscode.Position; 

let class2PackageMap;
let currentClassPackageName;
let importPosition;

// this method is called when your extension is activated
// your extension is activated the very first time the command is executed
function activate(context) {
    // The command has been defined in the package.json file
    // Now provide the implementation of the command with  registerCommand
    // The commandId parameter must match the command field in package.json
    let disposable = vscode.commands.registerTextEditorCommand('extension.organizeImports', function (editor, edit) {
        if(editor.document.languageId != "nextgenas")
            return; // Not as file

        let rootPath = vscode.workspace.rootPath;
        if(!rootPath)
            return; // No open folder

        let content = editor.document.getText();

        class2PackageMap = createClass2PackageMap(rootPath);
        currentClassPackageName = /package(?:\s+([\w.]*))?/.exec(content)[1] || "";

        let len = content.indexOf("{");
        importPosition = editor.document.positionAt(len);
        importPosition = new Position(importPosition.line + 1, 0);

        for(let i = 0; i < editor.document.lineCount; i++)
        {
            let line = editor.document.lineAt(i);
            
            // Delete old imports.
            if(/^\s*import\s+.*/.test(line.text))
                edit.delete(line.rangeIncludingLineBreak);
            // Insert imports.
            else
            {
                // Type casting.
                let result = /(\w+)\(\w+\)/.exec(line.text);
                if(result)
                {
                    let type = result[1];
                    let pattern = new RegExp("var\\s+" + type + "\\s*:\\s*Function|\\bfunction\\s+" + type + "\\(");

                    if(!pattern.test(content))
                    {
                        insertImport(type, edit);
                    }
                }
                
                // Static member
                let pattern = /\b(\w+)\.\w+/g;
                while(result = pattern.exec(line.text))
                {
                    let type = result[1];
                    let pattern = new RegExp("var\\s+" + type + "\\s*:");
                    if(!pattern.test(content))
                    {
                       insertImport(type, edit);
                    }
                }

                result = 
                    /var\s+\w+\s*:\s*(\w+)/.exec(line.text) || 
                    /\s+as\s(\w+)/.exec(line.text) ||
                    /\sextends\s(\w+)/.exec(line.text) ||
                    /\simplements\s(\w+)/.exec(line.text);

                if(result)
                {
                    let type = result[1];
                    insertImport(type, edit);
                }
            }
        }
    });

    context.subscriptions.push(disposable);
}
exports.activate = activate;

// this method is called when your extension is deactivated
function deactivate() {
}
exports.deactivate = deactivate;

function insertImport(type, edit)
{
    if(class2PackageMap[type])
    {
        type = class2PackageMap[type];
        let packageName = /(?:(.*)\.)?\w+$/.exec(type)[1] || "";
        // In same package. Need no import.
        if(packageName == currentClassPackageName)
            return;

        let importSection = "\timport " + type + ";\n";
        edit.insert(importPosition, importSection);
    }
}

function createClass2PackageMap(rootPath)
{
    let ret = {};

    // Default source directory.
    let classPath = path.join(rootPath, "src"); 
    walkDir(classPath, ret, classPath);

    // Other source paths.
    try
    {
        let asconfigString = fs.readFileSync(path.join(rootPath, "asconfig.json"));
        let asconfigJson = JSON.parse(asconfigString);
        let sourcePaths = asconfigJson.compilerOptions["source-path"];

        for(let i = 0; i < sourcePaths.length; i++)
        {
            let sourcePath = sourcePaths[i];
            if(!path.isAbsolute(sourcePath))
                sourcePath = path.join(rootPath, sourcePath);

            walkDir(sourcePath, ret, sourcePath);
        }
    }
    catch(e)
    {
        // asconfig.json not exist.
        // json syntax error.
        // no compilerOptions field.
        // no source-path field.
    }

    return ret;
}

function walkDir(dir, map, classPath)
{
    fs.readdirSync(dir).forEach((file) => 
    {
        let fullPath = path.join(dir, file);
        let stat = fs.statSync(fullPath);
        if(stat.isDirectory())
            walkDir(fullPath, map, classPath);
        else if(path.extname(fullPath) == ".as")
        {
            let fullClassName = path.relative(classPath,fullPath);
            fullClassName = fullClassName
                // Trim extension.
                .substring(0, fullClassName.length - 3)
                // Use 'dot' instead of 'path separator'
                .replace(/\/|\\/g, '.');

            let className = /\w+$/.exec(fullClassName)[0];
            map[className] = fullClassName;
        }
    });
}